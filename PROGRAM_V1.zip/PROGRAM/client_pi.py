from __future__ import print_function
from collections import deque
from imutils.object_detection import non_max_suppression
from imutils import paths
from threading import Thread
from multiprocessing import Process, Queue
import sys
import numpy as np
import argparse
import time
import socket
import selectors

global import_error

try:
    import cv2
    import imutils
    import io
    from picamera.array import PiRGBArray
    from picamera import PiCamera
    import_error = False
except ImportError as imp:
    print("IMPORTANT  :   WITHOUT OPENCV3.0 THE STEREOSCOPICS WILL NOT OPERATE" + str(imp))
    import_error = True

centroid = (0, 0)
compvalue = "1.0"

HOST = '169.254.116.12'  # Define the IP address for communication
PORT = 5025
BUFFER_SIZE = 1024
serverPi = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
frame_width = 640
frame_height = 448
resolution = (frame_width, frame_height)

hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
sel = selectors.DefaultSelector()

ap = argparse.ArgumentParser()
ap.add_argument("-v", "--video", help="path to the (optional) video file")
ap.add_argument("-b", "--buffer", type=int, default=8, help="max buffer size")
args = vars(ap.parse_args())

# define the lower and upper boundaries of the jersey ball in the HSV color space, then initialize the list of tracked points
jerseyLower1 = (0, 70, 70)  # currently set for red
jerseyUpper1 = (10, 255, 255)
jerseyLower2 = (170, 70, 70)  # currently set for red
jerseyUpper2 = (180, 255, 255)
pts = deque(maxlen=args["buffer"])

max_samples = 5
right_x_coord = deque(maxlen=args["buffer"])

def HOGcheck(image):
    frame = image
    (rects, weights) = hog.detectMultiScale(frame, winStride=(4, 4), padding=(8, 8), scale=1.05)
    check = False
    # apply non-maxima suppression to the bounding boxes using a
    # fairly large overlap threshold to try to maintain overlapping
    # boxes that are still people
    rects = np.array([[x, y, x + w, y + h] for (x, y, w, h) in rects])
    pick = non_max_suppression(rects, probs=None, overlapThresh=0.65)

    xA = pick[0]
    xB = pick[1]

    center = xA + (xB - xA)
    return center


def ProcessLoop(vs, PORT, BUFFER_SIZE, HOST, serverPi):
    hog_check = False

    while True:
        # print("looping")
        start_time = time.time()

        ## CHANGE THE WAY YOU ACQUIRE IMAGE
        try:
            image = vs.read()
            image = imutils.resize(image, width=frame_width, height=frame_height)
        except AttributeError as e:
            print("no image")
            capture = False
            while not capture:
                image = vs.read()
                image = imutils.resize(image, width=frame_width, height=frame_height)
                try:
                    image = vs.read()
                    image = imutils.resize(image, width=frame_width, height=frame_height)
                    capture = True
                except AttributeError as e:
                    print("no image")
                    capture = False
                    continue
                except:
                    print("no image")
                    break
        else:

            if hog_check:
                center = HOGcheck(image)
                right_x_coord.appendleft(center)

            else:
                blurred = cv2.GaussianBlur(image, (11, 11), 0)
                hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

                mask0 = cv2.inRange(hsv, jerseyLower1, jerseyUpper1)
                mask1 = cv2.inRange(hsv, jerseyLower2, jerseyUpper2)
                mask = mask0 + mask1
                mask = cv2.erode(mask, None, iterations=2)
                mask = cv2.dilate(mask, None, iterations=2)

                # find contours in the mask and initialize the current (x, y) center of the ball
                cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                cnts = imutils.grab_contours(cnts)
                center = None

                # only proceed if at least one contour was found
                if len(cnts) > 0:
                    # find the largest contour in the mask, then use it to compute the minimum
                    # enclosing circle and centroid
                    c = max(cnts, key=cv2.contourArea)
                    #            ((x, y), radius) = cv2.minEnclosingCircle(c)
                    M = cv2.moments(c)
                    center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
                    centroid = (round((M["m10"] / M["m00"]), 3), round((M["m01"] / M["m00"]), 3))
                    centroid = (centroid[0] * 2464 / frame_width, centroid[1] * 2464 / frame_height)
                    # only proceed if the radius meets a minimum size

                    right_x_coord.appendleft(float(centroid[0]))
                    if len(right_x_coord) == max_samples:
                        right_x_coord.pop()
                    #     mean = float(sum(right_x_coord)/max_samples,1)
                    #     if abs(mean - right_x_coord[0]) >= 100:
                    #         hog_check = True
                    #         right_x_coord.popleft()
                    #         print("HOG Check")
                            #check = HOGcheck(image,right_x_coord[4])
                            #if check:
                                #right_x_coord.popleft()


                    # value = str(x)
                    # print("X-coordinate: " + value)
                    # Send Data and Sockets Reconnection loop
                    try:
                        data = str(right_x_coord[0])
                        serverPi.send((data).encode())
                        # returndata = serverPi.recv(BUFFER_SIZE)
                    except socket.error:
                        connected = False
                        print('connection lost... reconnecting')
                        while not connected:
                            try:
                                serverPi = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                                serverPi.connect((HOST, PORT))
                                connected = True
                                print('reconnection successful')
                            except socket.error:
                                print("socket error")
                                time.sleep(2)
                            except Exception as e:
                                print("Some exception:  ", e)  # try:
                    #                serverPi.send((value).encode())
                    #                data = serverPi.recv(BUFFER_SIZE)
                    #            except socket.error:
                    #                reconnect()
                    FPS = time.time() - start_time
                    print("FPS: " + str(FPS))


class PiVideoStream:
    def __init__(self, resolution=(frame_width, frame_height), framerate=32):
        # initialize the camera and stream
        self.camera = PiCamera()
        self.camera.resolution = resolution
        self.camera.framerate = framerate
        self.rawCapture = PiRGBArray(self.camera, size=resolution)
        self.stream = self.camera.capture_continuous(self.rawCapture, format="bgr", use_video_port=True)

        # initialize the frame and the variable used to indicate
        # if the thread should be stopped
        self.frame = None
        self.stopped = False
        print("[Camera Thread] : Initializing camera")
        time.sleep(1)

    def start(self):
        # start the thread to read frames from the video stream
        Thread(target=self.update, args=()).start()
        return self

    def update(self):
        # keep looping infinitely until the thread is stopped
        for f in self.stream:
            # grab the frame from the stream and clear the stream in
            # preparation for the next frame
            self.frame = f.array
            self.rawCapture.truncate(0)

            # if the thread indicator variable is set, stop the thread
            # and resource camera resources
            if self.stopped:
                self.stream.close()
                self.rawCapture.close()
                self.camera.close()
                return

    def read(self):
        # return the frame most recently read
        return self.frame

    def stop(self):
        # indicate that the thread should be stopped
        self.stopped = True


def read(self):
    # return the frame most recently read
    return self.frame


def stop(self):
    # indicate that the thread should be stopped
    self.stopped = True


# created a *threaded* video stream, allow the camera sensor to warmup,
# and start the FPS counter

print("[INFO] starting THREADED frames from `picamera` module...")
vs = PiVideoStream().start()
time.sleep(2.0)

talking = False
while not talking:
    try:
        serverPi.connect((HOST, PORT))
        talking = True
    except:
        print('Stereoscopics:   No Server')
        time.sleep(3)
        continue
print('connected to serverpi')

ProcessLoop(vs, PORT, BUFFER_SIZE, HOST, serverPi)


