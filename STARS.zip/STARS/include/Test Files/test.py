new_distance = 10.0
boost_time = -0.03 * new_distance + 1.8
print(boost_time)