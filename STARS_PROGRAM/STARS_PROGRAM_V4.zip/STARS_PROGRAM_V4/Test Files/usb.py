import serial
import serial.tools.list_ports

ports = list(serial.tools.list_ports.comports())
for p in ports:
    # print(p)           # This causes each port's information to be printed out.
    if "0043" in p[2]:
        print (p[0])
print ('NULL')
